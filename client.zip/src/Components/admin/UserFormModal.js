import React, { useState, useEffect } from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import { Form, Col } from 'react-bootstrap';

export default function UserFormModal({ show, onHide, selectedUser }) {
    const [user, setUser] = useState({});
    const onChangeHandler = (e, type) => {
        let data = {};
        data[type] = e.target.value;
        setUser(data);
        console.warn(data);
    };

    const ok = (e) => {
        e.preventDefault();
        console.warn(user);
    };

    useEffect(() => {
        console.warn(selectedUser);
        console.info(user);
        setUser(selectedUser);
    }, []);

    return (
        <Modal
            show={show}
            onHide={onHide}
            size='lg'
            aria-labelledby='contained-modal-title-vcenter'
            centered>
            <Modal.Header closeButton>
                <Modal.Title id='contained-modal-title-vcenter'>
                    Edit User
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    <Form.Row>
                        <Col>
                            <Form.Control
                                placeholder='First name'
                                value={user.name}
                                onChange={(e) => onChangeHandler(e, 'name')}
                            />
                        </Col>
                        <Col>
                            <Form.Control
                                placeholder='Last name'
                                value={user.lastName}
                                onChange={(e) => onChangeHandler(e, 'lastName')}
                            />
                        </Col>
                    </Form.Row>
                    <Form.Row>
                        <Form.Group as={Col} controlId='formGridEmail'>
                            <Form.Label>Email</Form.Label>
                            <Form.Control
                                type='email'
                                placeholder={selectedUser.email}
                                value={user.email}
                                onChange={(e) => onChangeHandler(e, 'email')}
                            />
                        </Form.Group>
                    </Form.Row>
                    <Button variant='primary' type='button' onClick={ok}>
                        Submit
                    </Button>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button onClick={onHide}>Close</Button>
            </Modal.Footer>
        </Modal>
    );
}
